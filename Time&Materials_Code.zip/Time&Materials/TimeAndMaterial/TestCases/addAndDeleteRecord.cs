using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Runtime;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System;

namespace TimeAndMaterialProject
{
    public class TestCases
    {
        public static IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            // Browser initiate 
            driver = new ChromeDriver(@"C:\Georgin\Selenium\Test_Delete\Test_Delete\Test_Delete\bin\Debug\netcoreapp2.1\");

            //navigate to horse-dev
            driver.Navigate().GoToUrl("http://horse-dev.azurewebsites.net/Account/Login?ReturnUrl=%2f");

            //maximize t
            driver.Manage().Window.Maximize();
            //Login loginInstance = new Login(driver);
            //loginInstance.LoginSuccess();
        }

        Login lg = new Login();
        HomePage homeInstance = new HomePage();
        TimeAndMaterial tmPage = new TimeAndMaterial();
        DeleteRecord delRec = new DeleteRecord();

        [Test]
        public void CreateTMnValidate()
        {
            lg.LoginSuccess(driver);
            homeInstance.VerifyHomePage(driver);
            homeInstance.ClickAdminstration(driver);
            homeInstance.ClickTimenMaterial(driver);
            tmPage.ClickCreateNew(driver);
            tmPage.EnterValidDataandSave(driver);
        }
        [Test]
        public void DeleteRecord()
        {
            lg.LoginSuccess(driver);
            homeInstance.VerifyHomePage(driver);
            homeInstance.ClickAdminstration(driver);
            homeInstance.ClickTimenMaterial(driver);
            delRec.findRecordToDelete(driver);
        }

        [TearDown]
        public void TearDown()
        {
            driver.Close();
        }

    }
}