﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Test_Delete.SpecFlow
{
    [Binding]
    public class TimeAndMaterialsSteps
    {
        public static IWebDriver driver;
        [Given(@"Launch the Chrome browser")]
        public void GivenLaunchTheChromeBrowser()
        {
            // Browser initiate 
            driver = new ChromeDriver(@"C:\Personal\Teny\IC\Selenium\24Aug19\Test_Delete\Test_Delete\bin\Debug\netcoreapp2.1\");

            //navigate to horse-dev
            driver.Navigate().GoToUrl("http://horse-dev.azurewebsites.net/Account/Login?ReturnUrl=%2f");

            //maximize t
            driver.Manage().Window.Maximize();
            //Login loginInstance = new Login(driver);
            //loginInstance.LoginSuccess();
            //ScenarioContext.Current.Pending();
        }

        [Given(@"Login to Home page")]
        public void GivenLoginToHomePage()
        {
            //Login lg = new Login();
            //lg.LoginSuccess(driver);
            //ScenarioContext.Current.Pending();
        }
        
        [When(@"I click the Admistration")]
        public void WhenIClickTheAdmistration()
        {
            //ScenarioContext.Current.Pending();
        }
        
        [When(@"I click the Time & Materials")]
        public void WhenIClickTheTimeMaterials()
        {
            //ScenarioContext.Current.Pending();
        }
        
        [Then(@"TimeMaterial page should display")]
        public void ThenTimeMaterialPageShouldDisplay()
        {
            //ScenarioContext.Current.Pending();
        }
    }
}
