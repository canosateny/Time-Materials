﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Runtime;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using Test_Delete;

namespace TimeAndMaterialProject
{
    public class TimeAndMaterial
    {
        internal void ClickCreateNew(IWebDriver driver)
        {
            IWebElement CreateNew = driver.FindElement(By.XPath("//*[@id=\"container\"]/p/a"));
            CreateNew.Click();
        }
        internal void EnterValidDataandSave(IWebDriver driver)
        {
            ExcelUtil util = new ExcelUtil();
            util.PopulateInCollection(@"C:\Georgin\Selenium\testdata.xlsx", "Sheet2");

            IWebElement code = driver.FindElement(By.Id("Code"));
            code.SendKeys(util.ReadData(1, "Code"));
            //code.SendKeys("Ethan1");
            IWebElement Description = driver.FindElement(By.Id("Description"));
            Description.SendKeys(util.ReadData(1, "Description"));
            //Description.SendKeys("Trial123");
            IWebElement Priceperunit = driver.FindElement(By.XPath("//*[@id=\"TimeMaterialEditForm\"]/div/div[4]/div/span[1]/span/input[1]"));
            Priceperunit.SendKeys(util.ReadData(1, "Price Per Unit"));
            //Priceperunit.SendKeys("2014");
            IWebElement save = driver.FindElement(By.Id("SaveButton"));
            save.Click();
            Thread.Sleep(2000);

            //Find the record

            try
            {
                //IWebElement nextPage = driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[4]/a[3]/span"));

                bool hasNextPage = true;

                while (hasNextPage)
                {
                    for (int i = 1; i <= 10; i++)
                    {
                        List<String> NewRecord = new List<String>();
                        ReadOnlyCollection<IWebElement> record = driver.FindElements(By.XPath("//*[@id=\"tmsGrid\"]/div[3]/table/tbody/tr[" + i + "]"));
                        foreach (IWebElement row in record)
                        {
                            NewRecord.Add(row.Text);
                            string ev = "1234 M QA $2,000.01 EditDelete";
                            if (row.Text == ev)
                            {
                                Console.WriteLine("Record Found");
                                return;
                            }

                        }
                    }
                    IWebElement nextPage = driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[4]/a[3]/span"));
                    //IWebElement GoToTheLastPage = driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[4]/a[4]/span"));
                    //if (nextPage.Enabled)
                    //{
                    //    //driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[4]/a[3]/span")).Click();
                    //    nextPage.Click();
                    //}
                    //else
                    //{
                    //    Console.WriteLine("Test Failed, No Record found");
                    //    driver.Close();  
                    //}
                    
                    if (!nextPage.Enabled)
                    {
                        //driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[4]/a[3]/span")).Click();
                        hasNextPage = false;
                        Console.WriteLine("Test Failed, No Record found");
                        Console.WriteLine(nextPage.Enabled);
                        driver.Close();
                    }
                    else if (nextPage.Enabled)
                    {
                        //driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[4]/a[3]/span")).Click();
                        Console.WriteLine(nextPage.Enabled);
                        nextPage.Click();
                    }
                    else
                    {
                        Console.WriteLine(nextPage.Enabled);
                        return;
                    }


                }

            }

            catch (Exception)
            {
                Console.WriteLine("Test Failed, No Record found catch");
                driver.Close();
            }
        }
    }
}
           
