﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;


namespace TimeAndMaterialProject
{
    public class DeleteRecord
    {
        public void findRecordToDelete(IWebDriver driver)
        {

            while (true)
            {

                for (int i = 1; i <= 10; i++)
                {
                    List<String> textofrecord = new List<String>();
                    ReadOnlyCollection<IWebElement> listOfElements = driver.FindElements(By.XPath("//*[@id=\"tmsGrid\"]/div[3]/table/tbody/tr[" + i + "]"));
                    //try
                    //{
                    foreach (IWebElement record in listOfElements)
                    {
                        textofrecord.Add(record.Text);
                        string temp = "1234 " + "M " + "QA " + "$10.00 " + "EditDelete";
                        if (temp == record.Text)
                        {
                            driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[3]/table/tbody/tr[" + i + "]/td[5]/a[2]")).Click();
                            Thread.Sleep(2000);
                            IAlert alert = driver.SwitchTo().Alert();
                            alert.Accept();
                            return;

                            //found = 1;


                        }

                    }

                    //}

                    //catch (Exception e)
                    //{
                    //    Console.WriteLine("Delete failed");
                    //}
                }

                IWebElement goToNextPage = driver.FindElement(By.XPath("//*[@id=\"tmsGrid\"]/div[4]/a[3]/span"));
                if (goToNextPage.Enabled)
                {
                    goToNextPage.Click();
                }

                else
                {
                    Console.WriteLine("Record not found to delete");
                    return;
                }
            }
        }

    }
}
