﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Runtime;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System;

namespace TimeAndMaterialProject
{
    public class HomePage

    {
        internal void VerifyHomePage(IWebDriver driver)
        {
            //assignment is to check whether hello hari is displayed on the page 
            IWebElement username = driver.FindElement(By.XPath("//a[contains(.,'Hello hari!')]"));
            Console.WriteLine("username.Text " + username.Text);

            //if (username.Text == "Hello hari!")
            //    Console.WriteLine("verification passed - username disaplyed on home page");
            //else
            //    Console.WriteLine("verification failed - username not disaplyed on home page ");
            
            //Assertion for username is diplayed
            Assert.AreEqual("Hello hari!", username.Text,"Username is Verified");

        }
        internal void ClickAdminstration(IWebDriver driver)
        {
            IWebElement administration = driver.FindElement(By.XPath("/html/body/div[3]/div/div/ul/li[5]/a"));
            administration.Click();
        }
        internal void ClickTimenMaterial(IWebDriver driver)
        {
            //Click Time n Material 
            IWebElement TM = driver.FindElement(By.XPath("/html/body/div[3]/div/div/ul/li[5]/ul/li[3]/a"));
            TM.Click();
        }

       
        
    }
}
