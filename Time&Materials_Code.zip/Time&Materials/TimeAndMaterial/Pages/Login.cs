﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Runtime;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System;
using OpenQA.Selenium.Support.UI;
using Test_Delete;

/*
 *
    Username	Password
    hari	    123123



 * 
 * */


namespace TimeAndMaterialProject
{
    public class Login

    {
        internal void LoginSuccess(IWebDriver driver)
        {
            ExcelUtil util = new ExcelUtil();
            util.PopulateInCollection(@"C:\Georgin\Selenium\testdata.xlsx", "Sheet1");            
            //string un = util.ReadData(1, "Username");
            //string pwd = util.ReadData(1, "Password");

            //Explicit Time delay
            WebDriverWait waitForUserName = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            //waitForUserName.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("UserName")));
            waitForUserName.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.CssSelector("#UserName")));
          
            IWebElement username = driver.FindElement(By.Id("UserName"));
            username.SendKeys(util.ReadData(1, "Username"));
            //username.SendKeys(util.ReadData(1, columnName.Username.ToString()));


            //the below used enums
            //username.SendKeys(util.ReadData(1, columnName.Username.ToString()));

            WebDriverWait waitForPassword = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            waitForPassword.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("Password")));
            IWebElement password = driver.FindElement(By.Id("Password"));
            //password.Click();
            password.SendKeys(util.ReadData(1, "Password"));
            //username.SendKeys(util.ReadData(1, columnName.Password.ToString()));

            ////WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            //wait.Until(ExpectedConditions.ElementExists(By.XPath("//*[@id=\"loginForm\"]/form/div[3]/input[1]")));
            IWebElement login = driver.FindElement(By.XPath("//*[@id=\"loginForm\"]/form/div[3]/input[1]"));
            login.Click();
        }
    }


    public enum columnName
    {
        Username,
        Password
    }

}
